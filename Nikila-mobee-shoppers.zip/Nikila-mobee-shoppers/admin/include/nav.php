<div class="ch-container">
    <div class="row">
        
        <!-- left menu starts -->
        <div class="col-sm-2 col-lg-2">
            <div class="sidebar-nav">
                <div class="nav-canvas">
                    <div class="nav-sm nav nav-stacked">

                    </div>
                    <ul class="nav nav-pills nav-stacked main-menu">
                        <li class="nav-header">Main</li>
                        <li><a class="ajax-link" href="dashboard.php"><i class="glyphicon glyphicon-home"></i><span> Dashboard</span></a>
                        </li>
                         <li><a class="ajax-link" href="banner.php"><i class="glyphicon glyphicon-certificate"></i><span> Banner</span></a>
                        </li>
                        <li><a class="ajax-link" href="categories.php"><i class="glyphicon glyphicon-list-alt"></i><span> Categories</span></a>
                        </li>
                        <li><a class="ajax-link" href="collection.php"><i class="glyphicon glyphicon-star-empty"></i><span> Collection</span></a>
                        </li>
                        <li><a class="ajax-link" href="product.php"><i class="glyphicon glyphicon-eye-open"></i><span> Products</span></a>
                        </li>
                        <li><a class="ajax-link" href="cod.php"><i
                                    class="glyphicon glyphicon-globe"></i><span> COD Setup</span></a></li>

                        <li class="nav-header hidden-md">Order Managment</li>
                        <!--li><a class="ajax-link" href="pendingorder.php"><i
                                    class="glyphicon glyphicon-euro"></i><span> Pending Orer</span></a></li-->
                        <li><a class="ajax-link" href="vieworder.php"><i
                                    class="glyphicon glyphicon-ok-circle"></i><span> All Order</span></a></li>
                                    <li><a class="ajax-link" href="review.php"><i
                                    class="glyphicon glyphicon-ok-circle"></i><span> Review</span></a></li>
                        <li class="nav-header hidden-md">Manage Account Section</li>
                        <li><a class="ajax-link" href="account.php"><i
                                    class="glyphicon glyphicon-qrcode"></i><span> Account Settings</span></a></li>
                        <!--li class="accordion">
                            <a href="#"><i class="glyphicon glyphicon-plus"></i><span> Accordion Menu</span></a>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#">Child Menu 1</a></li>
                                <li><a href="#">Child Menu 2</a></li>
                            </ul>
                        </li>
                        <li><a class="ajax-link" href="calendar.html"><i class="glyphicon glyphicon-calendar"></i><span> Calendar</span></a>
                        </li>
                        <li><a class="ajax-link" href="grid.html"><i
                                    class="glyphicon glyphicon-th"></i><span> Grid</span></a></li>
                        <li><a href="tour.html"><i class="glyphicon glyphicon-globe"></i><span> Tour</span></a></li>
                        <li><a class="ajax-link" href="icon.html"><i
                                    class="glyphicon glyphicon-star"></i><span> Icons</span></a></li>
                        <li><a href="error.html"><i class="glyphicon glyphicon-ban-circle"></i><span> Error Page</span></a>
                        </li>
                        <li><a href="login.html"><i class="glyphicon glyphicon-lock"></i><span> Login Page</span></a>
                        </li-->
                    </ul>
                </div>
            </div>
        </div>
        <!--/span-->
        <!-- left menu ends -->
<?php
include_once('include/header.php');
include_once('include/nav.php');
include_once('phplib/view.php');
include_once('phplib/controler.php');


?>

<div style="margin-top: 150px;">&nbsp;</div>

<section class="payment_status">
	
	<div class="alert alert-success text-center">
  		<strong>Success!</strong> Your order is placed successfully. <b>Login</b> To Your Account to <b>Track Your Order</b>.
	</div>

</section>

<div style="margin-bottom: 150px;">&nbsp;</div>

<?php
include_once('include/footer.php');
?>
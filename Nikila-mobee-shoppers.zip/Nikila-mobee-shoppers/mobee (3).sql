-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2021 at 08:01 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobee`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `email`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(6, 'admin@gmail.com', 'c32ec3f6acebda0429a32496b5d5104c');

-- --------------------------------------------------------

--
-- Table structure for table `catrgories`
--

CREATE TABLE `catrgories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `catrgories`
--

INSERT INTO `catrgories` (`category_id`, `category_name`, `category_image`) VALUES
(15, 'Apple Phones', 'iphonebanner.jpg'),
(16, 'Samsung phones', 'samsungbanner.jpg'),
(17, 'Redmi Phones', 'redmibanner.jpg'),
(18, 'Nokia phones', 'nokiabanner.jpg'),
(20, 'OnePlus phones', 'googlebanner.jpg'),
(21, 'Huawei phones', 'huaweibanner.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cod_location`
--

CREATE TABLE `cod_location` (
  `location_id` int(11) NOT NULL,
  `pin` int(6) NOT NULL,
  `location` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cod_location`
--

INSERT INTO `cod_location` (`location_id`, `pin`, `location`) VALUES
(11, 32000, 'Ampara'),
(12, 30100, 'Kattankudy'),
(13, 30000, 'Batticaloa'),
(14, 50000, 'Anuradhapura'),
(15, 90000, 'Badulla'),
(16, 10120, 'Battaramulla'),
(17, 400, 'Bambalapitiya'),
(18, 600, 'Wellawatte');

-- --------------------------------------------------------

--
-- Table structure for table `collection`
--

CREATE TABLE `collection` (
  `collection_id` int(11) NOT NULL,
  `collection_name` varchar(255) NOT NULL,
  `collection_banner` varchar(255) NOT NULL,
  `collection_thumble` varchar(255) NOT NULL,
  `collection_details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `front_banner`
--

CREATE TABLE `front_banner` (
  `banner_id` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `front_banner`
--

INSERT INTO `front_banner` (`banner_id`, `url`, `image`) VALUES
(4, 'https://nikilaperera-f1218.web.app/', 'banner1.png'),
(5, 'https://nikilaperera-f1218.web.app/', 'bg2.jpg'),
(8, 'https://nikilaperera-f1218.web.app/', 'banner3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mobee_cart`
--

CREATE TABLE `mobee_cart` (
  `Cart_ID` int(11) NOT NULL,
  `User_ID` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_price` float NOT NULL,
  `qty` int(11) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobee_cart`
--

INSERT INTO `mobee_cart` (`Cart_ID`, `User_ID`, `product_id`, `product_price`, `qty`, `status`) VALUES
(84, '49303572560d0730de4d1f4.63736893', 28, 63000, 1, 'pending'),
(85, '15390459260d074b789a166.63460185', 49, 44000, 1, 'pending'),
(86, '44158105360d07c0e1aa878.84306782', 18, 99500, 1, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `mobee_newsletter`
--

CREATE TABLE `mobee_newsletter` (
  `request_id` int(11) NOT NULL,
  `request_by` varchar(255) NOT NULL,
  `datetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobee_newsletter`
--

INSERT INTO `mobee_newsletter` (`request_id`, `request_by`, `datetime`) VALUES
(5, 'nikilabanuka@gmail.com', '20-06-2021 23:37');

-- --------------------------------------------------------

--
-- Table structure for table `mobee_order`
--

CREATE TABLE `mobee_order` (
  `order_id` int(11) NOT NULL,
  `cart_id` varchar(255) NOT NULL,
  `order_by` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `landmark` varchar(255) DEFAULT NULL,
  `pin` varchar(6) NOT NULL,
  `province` varchar(255) NOT NULL,
  `totalamount` float NOT NULL,
  `deliverycharge` float NOT NULL,
  `date` varchar(20) NOT NULL,
  `time` time NOT NULL,
  `mode` varchar(255) NOT NULL,
  `payment` tinyint(1) NOT NULL DEFAULT 0,
  `current_status` varchar(255) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobee_order`
--

INSERT INTO `mobee_order` (`order_id`, `cart_id`, `order_by`, `email`, `phone`, `address`, `landmark`, `pin`, `province`, `totalamount`, `deliverycharge`, `date`, `time`, `mode`, `payment`, `current_status`) VALUES
(65, '44158105360d07c0e1aa878.84306782', 'nikila perera', 'nikilabanuka@gmail.com', '0764343952', '66/2 baddagana road,pitakotte', 'rooftop', '10100', 'Colombo', 99500, 50, '2021-06-21', '17:16:00', 'Cash On Delivery', 1, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `mobee_product`
--

CREATE TABLE `mobee_product` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `selling` float NOT NULL,
  `special` tinyint(1) DEFAULT NULL,
  `SKU` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobee_product`
--

INSERT INTO `mobee_product` (`product_id`, `product_name`, `description`, `image`, `price`, `selling`, `special`, `SKU`) VALUES
(16, 'I Phone 7', 'I Phone 7', 'i7.jpg', 78000, 73000, 1, 'MSIP001'),
(17, 'I Phone 7Plus', 'I Phone 7Plus', 'i7+.jpg', 95000, 89000, 1, 'MSIP002'),
(18, 'I Phone 8', 'I Phone 8', 'i8.png', 101000, 99500, 1, 'MSIP003'),
(19, 'I Phone 8+', 'I Phone 8Plus', 'i8+.jpg', 112000, 101100, 1, 'MSIP004'),
(20, 'I Phone 11', 'I Phone 11', 'i11.jpg', 148000, 134000, 1, 'MSIP005'),
(21, 'I Phone 11 MAX', 'I Phone 11 MAX', 'i11max.jpg', 154000, 150100, 1, 'MSIP006'),
(22, 'I Phone 11 Pro', 'I Phone 11 Pro', 'i11pro.jpeg', 168020, 160000, 1, 'MSIP007'),
(23, 'I Phone 12', 'I Phone 12', 'i12.jpg', 220000, 210000, 1, 'MSIP008'),
(24, 'I Phone 12 Pro', 'I Phone 12 Pro', 'i12pro.jpg', 310000, 298000, 1, 'MSIP009'),
(25, 'I Phone 12 Pro Max', 'I Phone 12 Pro Max', 'i12promax.jpeg', 350000, 338000, 1, 'MSIP010'),
(26, 'I phone x', 'I Phone x', 'ix.jpg', 115000, 103000, 1, 'MSIP011'),
(27, 'I Phone XR', 'I Phone XR', 'ixr.jpg', 115000, 113000, 1, 'MSIP012'),
(28, 'Samsung A51', 'Samsung A51', 'sa51.jpg', 68000, 63000, 1, 'MSS001'),
(29, 'Samsung A52', 'Samsung A52', 'sa52.jpg', 74000, 69000, 1, 'MSS002'),
(30, 'Samsung A71', 'Samsung A71', 'sa71.jpg', 79000, 75000, 1, 'MSS003'),
(31, 'Samsung A80', 'Samsung A80', 'sa80.jpg', 84000, 80000, 1, 'MSS004'),
(32, 'Samsung Note 9', 'Samsung Note 9', 'snote9.jpg', 88000, 84000, 1, 'MSS005'),
(33, 'Samsung Note10', 'Samsung Note10', 'snote10.jpg', 94000, 90500, 1, 'MSS006'),
(34, 'Samsung S 8', 'Samsung S 8', 'ss8.jpg', 68000, 63000, 1, 'MSS007'),
(35, 'Samsung S 9', 'Samsung S 9', 'ss9.jpg', 88000, 84000, 1, 'MSS008'),
(36, 'Samsung S 10', 'Samsung S 10', 'ss10.jpg', 88000, 84000, 1, 'MSS009'),
(37, 'Samsung S 20', 'Samsung S 20', 'ss20.jpg', 132000, 128000, 1, 'MSS010'),
(38, 'Samsung S 21', 'Samsung S 21', 'ss21.jpg', 198000, 176000, 1, 'MSS011'),
(40, 'Redmi Note 7', 'Redmi Note 7', 'rnote7.jpg', 32000, 28000, 1, 'MSR001'),
(41, 'Redmi Note 8', 'Redmi Note 8', 'rnote8.jpg', 36000, 34000, 1, 'MSR002'),
(42, 'Redmi Note 9', 'Redmi Note 9', 'rnote9.jpg', 42000, 38000, 1, 'MSR003'),
(43, 'Redmi Note 9 Pro', 'Redmi Note 9 Pro', 'rnote9pro.jpg', 49000, 44500, 1, 'MSR004'),
(44, 'Redmi Note 9s', 'Redmi Note 9s', 'rnote9s.jpg', 54000, 50500, 1, 'MSR005'),
(45, 'Nokia 3.2', 'Nokia 3.2', 'n3.2.jpg', 24000, 21500, 1, 'MSN001'),
(46, 'Nokia 2.3', 'Nokia 2.3', 'n2.3.jpg', 22000, 19000, 1, 'MSN002'),
(47, 'Nokia 4.2', 'Nokia 4.2', 'n4.2.jpg', 38000, 33000, 1, 'MSN003'),
(48, 'Nokia 5', 'Nokia 5', 'n5.jpg', 42000, 38000, 1, 'MSN004'),
(49, 'Nokia 6', 'Nokia 6', 'n6.jpg', 48000, 44000, 1, 'MSN005'),
(54, 'Nokia 7', 'Nokia 7', 'n7.jpg', 55000, 50500, 1, 'MSN006'),
(55, 'Nokia 8', 'Nokia 8', 'n8.jpg', 68000, 63000, 1, 'MSN007'),
(56, 'OnePlus 3T', 'OnePlus 3T', '03t.jpg', 30500, 28500, 1, 'MSO001'),
(57, 'OnePlus 5T', 'OnePlus 5T', 'o5t.jpg', 45000, 42500, 1, 'MSO002'),
(58, 'OnePlus 6T', 'OnePlus 6T', 'o6t.jpg', 52000, 49000, 1, 'MSO003'),
(59, 'OnePlus 7T', 'OnePlus 7T', 'o7t.jpg', 72000, 69000, 1, 'MSO004'),
(60, 'OnePlus 9T', 'OnePlus 9T', 'o9t.jpg', 98000, 92000, 1, 'MSO005'),
(61, 'Huawei Nova 8', 'Huawei Nova 8', 'hnova8.jpg', 24000, 22000, 1, 'MSH001'),
(62, 'Huawei P 30', 'Huawei P 30', 'hp30.jpg', 29000, 25000, 1, 'MSH002'),
(63, 'Huawei Y7', 'Huawei Y7', 'hy7.jpg', 30000, 25000, 1, 'MSH003'),
(64, 'Huawei Y9', 'Huawei Y9', 'hy9.jpg', 32000, 29000, 1, 'MSH004'),
(65, 'Huawei Y9 PRO', 'Huawei Y9 PRO', 'hy9pro.jpg', 42000, 38000, 1, 'MSH005');

-- --------------------------------------------------------

--
-- Table structure for table `mobee_productimage`
--

CREATE TABLE `mobee_productimage` (
  `image_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobee_productimage`
--

INSERT INTO `mobee_productimage` (`image_id`, `product_id`, `image_path`) VALUES
(30, 16, 'i7.jpg'),
(31, 16, 'i7.jpg'),
(32, 17, 'i7+.jpg'),
(33, 17, 'i7+.jpg'),
(34, 18, 'i8.png'),
(35, 18, 'i8.png'),
(36, 19, 'i8+.jpg'),
(37, 19, 'i8+.jpg'),
(38, 20, 'i11.jpg'),
(39, 20, 'i11.jpg'),
(40, 21, 'i11max.jpg'),
(41, 21, 'i11max.jpg'),
(42, 22, 'i11pro.jpeg'),
(43, 22, 'i11pro.jpeg'),
(44, 23, 'i12.jpg'),
(45, 23, 'i12.jpg'),
(46, 24, 'i12pro.jpg'),
(47, 24, 'i12pro.jpg'),
(48, 25, 'i12promax.jpeg'),
(49, 25, 'i12promax.jpeg'),
(50, 26, 'ix.jpg'),
(51, 26, 'ix.jpg'),
(52, 27, 'ixr.jpg'),
(53, 27, 'ixr.jpg'),
(54, 28, 'sa51.jpg'),
(55, 28, 'sa51.jpg'),
(56, 29, 'sa52.jpg'),
(57, 29, 'sa52.jpg'),
(58, 30, 'sa71.jpg'),
(59, 30, 'sa71.jpg'),
(60, 31, 'sa80.jpg'),
(61, 31, 'sa80.jpg'),
(62, 32, 'snote9.jpg'),
(63, 32, 'snote9.jpg'),
(64, 33, 'snote10.jpg'),
(65, 33, 'snote10.jpg'),
(66, 34, 'ss8.jpg'),
(67, 34, 'ss8.jpg'),
(68, 35, 'ss9.jpg'),
(69, 35, 'ss9.jpg'),
(70, 36, 'ss10.jpg'),
(71, 36, 'ss10.jpg'),
(72, 37, 'ss20.jpg'),
(73, 37, 'ss20.jpg'),
(74, 38, 'ss21.jpg'),
(75, 38, 'ss21.jpg'),
(82, 40, 'rnote7.jpg'),
(83, 40, 'rnote7.jpg'),
(84, 47, 'n4.2.jpg'),
(85, 47, 'n4.2.jpg'),
(86, 41, 'rnote8.jpg'),
(87, 41, 'rnote8.jpg'),
(88, 42, 'rnote9.jpg'),
(89, 42, 'rnote9.jpg'),
(90, 43, 'rnote9pro.jpg'),
(91, 43, 'rnote9pro.jpg'),
(92, 44, 'rnote9s.jpg'),
(93, 44, 'rnote9s.jpg'),
(94, 45, 'n3.2.jpg'),
(95, 45, 'n3.2.jpg'),
(96, 46, 'n2.3.jpg'),
(97, 46, 'n2.3.jpg'),
(98, 48, 'n5.jpg'),
(99, 48, 'n5.jpg'),
(100, 49, 'n6.jpg'),
(101, 49, 'n6.jpg'),
(110, 54, 'n7.jpg'),
(111, 54, 'n7.jpg'),
(112, 55, 'n8.jpg'),
(113, 55, 'n8.jpg'),
(114, 56, '03t.jpg'),
(115, 56, '03t.jpg'),
(116, 57, 'o5t.jpg'),
(117, 57, 'o5t.jpg'),
(118, 58, 'o6t.jpg'),
(119, 58, 'o6t.jpg'),
(120, 59, 'o7t.jpg'),
(121, 59, 'o7t.jpg'),
(122, 60, 'o9t.jpg'),
(123, 60, 'o9t.jpg'),
(124, 61, 'hnova8.jpg'),
(125, 61, 'hnova8.jpg'),
(126, 62, 'hp30.jpg'),
(127, 62, 'hp30.jpg'),
(128, 63, 'hy7.jpg'),
(129, 63, 'hy7.jpg'),
(130, 64, 'hy9.jpg'),
(131, 64, 'hy9.jpg'),
(132, 65, 'hy9pro.jpg'),
(133, 65, 'hy9pro.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `mobee_user`
--

CREATE TABLE `mobee_user` (
  `customer_id` int(11) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_number` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `billing_address` varchar(255) DEFAULT NULL,
  `shipping_address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobee_user`
--

INSERT INTO `mobee_user` (`customer_id`, `customer_email`, `customer_name`, `customer_number`, `password`, `billing_address`, `shipping_address`) VALUES
(16, 'nikilabanuka@gmail.com', 'nikila perera', '+94764343952', '81dc9bdb52d04dc20036dbd8313ed055', '66/2 baddagana road,pitakotte', 'Sri Lanka');

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `record_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`record_id`, `product_id`, `category_id`) VALUES
(108, 54, 18),
(109, 55, 18),
(110, 56, 20),
(113, 57, 20),
(116, 61, 21),
(117, 62, 21),
(118, 63, 21),
(119, 64, 21),
(120, 65, 21),
(216, 40, 17),
(224, 48, 18),
(226, 58, 20),
(227, 59, 20),
(230, 17, 15),
(231, 18, 15),
(233, 19, 15),
(234, 20, 15),
(235, 21, 15),
(236, 22, 15),
(237, 23, 15),
(238, 24, 15),
(239, 25, 15),
(240, 26, 15),
(241, 27, 15),
(243, 28, 16),
(244, 29, 16),
(245, 30, 16),
(246, 31, 16),
(247, 32, 16),
(248, 33, 16),
(249, 34, 16),
(250, 35, 16),
(251, 36, 16),
(252, 37, 16),
(253, 38, 16),
(254, 41, 17),
(255, 42, 17),
(256, 43, 17),
(257, 44, 17),
(258, 45, 18),
(259, 46, 18),
(260, 47, 18),
(261, 49, 18),
(262, 60, 20),
(295, 16, 15);

-- --------------------------------------------------------

--
-- Table structure for table `product_collection`
--

CREATE TABLE `product_collection` (
  `record_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `collection_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_review`
--

CREATE TABLE `product_review` (
  `review_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `review_by(email)` varchar(255) NOT NULL,
  `review_by(name)` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `rate` float NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `catrgories`
--
ALTER TABLE `catrgories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `cod_location`
--
ALTER TABLE `cod_location`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `collection`
--
ALTER TABLE `collection`
  ADD PRIMARY KEY (`collection_id`);

--
-- Indexes for table `front_banner`
--
ALTER TABLE `front_banner`
  ADD PRIMARY KEY (`banner_id`);

--
-- Indexes for table `mobee_cart`
--
ALTER TABLE `mobee_cart`
  ADD PRIMARY KEY (`Cart_ID`);

--
-- Indexes for table `mobee_newsletter`
--
ALTER TABLE `mobee_newsletter`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `mobee_order`
--
ALTER TABLE `mobee_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `mobee_product`
--
ALTER TABLE `mobee_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `mobee_productimage`
--
ALTER TABLE `mobee_productimage`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `mobee_user`
--
ALTER TABLE `mobee_user`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`record_id`);

--
-- Indexes for table `product_collection`
--
ALTER TABLE `product_collection`
  ADD PRIMARY KEY (`record_id`);

--
-- Indexes for table `product_review`
--
ALTER TABLE `product_review`
  ADD PRIMARY KEY (`review_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `catrgories`
--
ALTER TABLE `catrgories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `cod_location`
--
ALTER TABLE `cod_location`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `collection`
--
ALTER TABLE `collection`
  MODIFY `collection_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `front_banner`
--
ALTER TABLE `front_banner`
  MODIFY `banner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `mobee_cart`
--
ALTER TABLE `mobee_cart`
  MODIFY `Cart_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `mobee_newsletter`
--
ALTER TABLE `mobee_newsletter`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `mobee_order`
--
ALTER TABLE `mobee_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `mobee_product`
--
ALTER TABLE `mobee_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT for table `mobee_productimage`
--
ALTER TABLE `mobee_productimage`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=302;

--
-- AUTO_INCREMENT for table `mobee_user`
--
ALTER TABLE `mobee_user`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=296;

--
-- AUTO_INCREMENT for table `product_collection`
--
ALTER TABLE `product_collection`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_review`
--
ALTER TABLE `product_review`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

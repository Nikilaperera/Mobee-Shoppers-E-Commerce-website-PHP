# php-and-mysqli-e-commerce
e-commerce using php and mysqli with cc-avenue payment gateway. <br/>
This is complite e-commerce site using php and my-sqli with cc-avenue payment gateway.<br>
<strong>I use my own logic to create all the stuff.</strong><br/>
Thanks.

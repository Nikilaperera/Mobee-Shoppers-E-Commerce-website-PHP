<?php
include_once('include/header.php');
include_once('include/nav.php');
include_once('phplib/view.php');
include_once('phplib/controler.php');


?>

<div style="margin-top: 150px;">&nbsp;</div>


<section class="payment_status">
	
	<div class="alert alert-danger text-center">
  			<strong>Error!</strong> Your payment could not completed.
	</div>

</section>




<div style="margin-bottom: 150px;">&nbsp;</div>

<?php
include_once('include/footer.php');
?>
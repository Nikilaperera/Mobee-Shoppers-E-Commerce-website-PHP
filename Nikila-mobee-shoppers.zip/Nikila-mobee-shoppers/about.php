<?php
include_once('include/header.php');
include_once('include/nav.php');
include_once('phplib/view.php');
include_once('phplib/controler.php');
if(!isset($_GET['name']))
{
	echo "<script>window.open('about.php?name=".base64_encode('About Us')."','_self');</script>";
}
?>

<!-- about -->
		<div class="privacy about">
			<h3>About Us</h3>
			
			<div class="agile_about_grids">
				<div class="col-md-6 agile_about_grid_right">
					<br><img src="images/12.jpeg" alt=" " class="img-responsive" />
				</div>
				<div class="col-md-6 agile_about_grid_right">
				<p class="animi" align="justify">Mobee-Shoppers is established in the year 1999 and started its retail business at Baseline Road. We are the one of the first mobile shop to list our retail pricelist in
					 our website without any gimmicks or hidden cost so that all potential buyers are aware of the actual price to pay upon purchase. We have grown from our humble beginning to a full fledge mobile
					  device outlet catering to the needs of the discerning user. Our business ethos have always been honestly and reliability, this is one reason why we have manage to expand it a very competitive industry.
					  Technical specifications of new mobile devices can be overwhelming, and can be difficult to understand. For this reason we try to explain each detail with utter most transparency making sure we do not mislead you.
					   We pride ourselves with a team of customer focus sales team, whose passion is to help every customer find the right mobile phone with the best pricing options. We carry a wide inventory of mobile phones and tablets from major brands, 
					   all models carries full warranty by the manufacturers. Our sales team is knowledgeable with the usage your devices and will be able to guide to a quick start.</p>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
<!-- //about -->

<!-- testimonials -->
	<div class="testimonials">
		<div class="container">
			<h3>Testimonials</h3>
				<div class="w3_testimonials_grids">
					<div class="wmuSlider example1 animated wow slideInUp" data-wow-delay=".5s">
						<div class="wmuSliderWrapper">
							<article style="position: absolute; width: 100%; opacity: 0;"> 
								<div class="banner-wrap">
									<div class="col-md-6 w3_testimonials_grid">
										<p><i class="fa fa-quote-right" aria-hidden="true"></i>Mobee-Shoppers is the best Mobile Shop than Mobile-Island in our Town</p>
										<h4>Pehasara Wickramathunga<span>Owner [Mobile-Island]</span></h4>
									</div>
									<div class="col-md-6 w3_testimonials_grid">
										<p><i class="fa fa-quote-right" aria-hidden="true"></i>Seeing his shop, I decided to close my shop and set up a phone shop like his.</p>
										<h4>Mohommad Nasik <span>Owner [Juicy]</span></h4>
									</div>
									<div class="clearfix"> </div>
								</div>
							</article>
							
							
						</div>
					</div>
					<script src="js/jquery.wmuSlider.js"></script> 
					<script>
						$('.example1').wmuSlider();         
					</script> 
				</div>
		</div>
	</div>
<!-- //testimonials -->
<?php
include_once('include/footer.php');
?>